/*MY TITLE.*/

//args: -Egoheader
//config_path: testdata/configs/go-header.yml
package testdata
