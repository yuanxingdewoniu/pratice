export { wrapRootElement } from "./src/@rocketseat/gatsby-theme-docs/gatsby/wrapRootElement";
export { wrapPageElement } from "./src/@rocketseat/gatsby-theme-docs/gatsby/wrapPageElement";
