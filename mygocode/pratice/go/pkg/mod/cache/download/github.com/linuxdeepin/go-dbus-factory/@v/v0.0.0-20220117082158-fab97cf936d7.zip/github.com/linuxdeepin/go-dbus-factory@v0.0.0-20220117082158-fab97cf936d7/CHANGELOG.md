[0.9.0] 2019-06-05
*   change(api): add com.deepin.WMSwitcher

[0.8.0] 2019-05-09
*   change(api): update com.deepin.wm

[0.7.0] 2019-04-09
*   change(api): update com.deepin.wm

[0.6.0] 2019-04-08
*   feat: update com.deepin.daemon.greeter and com.deepin.XSettings

[0.5.0] 2019-04-02
*   change(api): update com.deepin.daemon.greeter
*   change(api): update com.deepin.wm
*   change(api): add org.kde.kwin Compositor

[0.4.0] 2019-03-15
*   change(api): update com.deepin.api.SoundThemePlayer
*   change(api): add com.deepin.system.Network

[0.3.0] 2019-03-01
*   change(api): add com.deepin.dde.osd
*   change(api): update com.deepin.wm
*   feat: add com.deepin.api.soundthemeplayer
*   chore: update com.deepin.daemon.Network

[0.2.0] 2018-12-13
*   feat: add org.freedesktop.NetworkManager ObjectManager

[0.1.0] 2018-11-23
*   feat: update com.deepin.daemon.daemon
*   chore: add makefile for `sw_64`

[0.0.7] 2018-08-07
*   feat: update com.deepin.api.device

[0.0.6] 2018-07-31
*   chore: networkmanager accessPoint add accessor

[0.0.5] 2018-07-19
*   update com.deepin.sessionmanager XSettings
*   add net.hadess.sensorproxy
*   update org.freedesktop.notifications

[0.0.4] 2018-07-05
*   update com.deepin.system.power
*   update com.deepin.lastore
*   feat: policykit1 add manual code
*   update com.deepin.SessionManager

[0.0.3] 2018-05-14
*   chore: replace UnixFdIndex with UnixFd
*   update com.deepin.lastore/Job
*   feat: add org.bluez ObjectManager
*   add com.deepin.daemon.ImageBlur
*   add com.deepin.daemon.sessionwatcher

[0.0.2] 2018-04-19
*   feat(generator): common property type define supported
*   feat: autofill PropertyFix.EmptyValue
*   add org.freedesktop.colormanager
*   add org.freedesktop.modemmanager1
*   add org.freedesktop.networkmanager device
*   feat: add PropertyFix RenameTo
*   add net.reactivated.fprint.Device
*   add org.freedesktop.networkmanager
*   add org.freedesktop.miracle.wfd
*   add org.freedesktop.miracle.wifi
*   add org.mpris.mediaplayer2
*   update README
*   add README
*   add org.freedesktop.udisks2
*   add org.ayatana.bamf
*   add org.freedesktop.secrets
*   add org.freedesktop.policykit1
*   add org.freedesktop.timedate1
*   add org.freedesktop.notifications
*   add org.freedesktop.screensaver
*   add com.deepin.daemon.daemon
*   add com.deepin.daemon.greeter
*   add com.deepin.api.cursorhelper
*   add com.deepin.daemon.timedated
*   add com.deepin.daemon.accounts
*   add com.deepin.daemon.helper.backlight
*   add com.deepin.daemon.inputdevices
*   add com.deepin.daemon.gesture
*   add com.deepin.daemon.network
*   add com.deepin.api.localehelper
*   add com.deepin.api.pinyin
*   add com.deepin.system.power
*   add com.deepin.daemon.audio
*   add com.deepin.daemon.display
*   add com.deepin.dde.launcher
*   add com.deepin.daemon.apps
*   add com.deepin.api.device
*   add com.deepin.sessionmanager
*   add org.freedesktop.dbus
*   add org.bluez
*   add net.reactivated.fprint
*   add com.deepin.wm
*   change package name
*   add golang-dlib-dev

[0.0.1] 2018-03-28
*   regen
*   check whether the callback is nil
*   add com.deepin.lastore
*   add debian
*   regen
*   rename client to proxy
*   check path validity
*   add org.freedesktop.login1
*   generator +6
*   add .gitignore
*   add com.deepin.api.xeventmonitor
*   generator +5
*   add com.deepin.dde.daemon.dock
*   generator +4
*   generator +3
*   generator +2
*   generator +1
*   init
