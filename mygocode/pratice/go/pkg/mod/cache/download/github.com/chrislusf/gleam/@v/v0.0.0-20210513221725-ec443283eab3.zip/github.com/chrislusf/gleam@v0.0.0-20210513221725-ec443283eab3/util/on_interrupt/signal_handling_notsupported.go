// +build plan9

package on_interrupt

func OnInterrupt(fn func(), onExitFunc func()) {
}
