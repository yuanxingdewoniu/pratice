package procs

type ProcMessage struct {
	ExecPath   string
	CGroupPath string
	Pid        string
	PPid       string
}
