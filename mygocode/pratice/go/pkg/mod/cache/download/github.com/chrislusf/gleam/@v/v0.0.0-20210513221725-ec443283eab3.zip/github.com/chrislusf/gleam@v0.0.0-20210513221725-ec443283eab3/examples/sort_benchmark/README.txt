# Input Data

Fetch the code to build "gensort" on linux.
http://www.ordinal.com/gensort.html
Or linux prebuilt
http://www.ordinal.com/try.cgi/gensort-linux-1.5.tar.gz

gensort -a     10000 record_10K_input.txt

// The data input is 1GB gensort generated text data file.
gensort -a  10737418 record_1GB_input.txt

// The data input is 10GB gensort generated text data file.
gensort -a 107374180 record_10GB_input.txt


