package authenticate

type CharaInfo struct {
	CharaName string
	CharaType int32
}

type DriverInfo struct {
	DriverName string
	CharaType  int32
}
