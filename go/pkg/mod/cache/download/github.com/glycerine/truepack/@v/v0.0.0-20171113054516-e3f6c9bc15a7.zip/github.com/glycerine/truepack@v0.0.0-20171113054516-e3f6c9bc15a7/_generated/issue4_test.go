package _generated

import (
	"testing"
)

func Test222EncodeDecode(t *testing.T) {
	issue4EncodeDecode()
}
