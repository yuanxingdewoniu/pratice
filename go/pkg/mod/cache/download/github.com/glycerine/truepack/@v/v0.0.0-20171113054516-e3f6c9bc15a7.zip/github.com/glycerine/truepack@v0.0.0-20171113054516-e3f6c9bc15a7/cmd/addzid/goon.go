package main

//import goon "github.com/glycerine/go-goon"
import goon "github.com/shurcooL/go-goon"

// require that we download the go-goon package above, which is used by the tests
var _ = goon.Dump
