# libudev usage examples

See details in [this article](https://gavv.github.io/articles/libudev-usb/).
