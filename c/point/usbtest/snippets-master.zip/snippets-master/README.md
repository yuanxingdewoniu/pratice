Random code snippets. All code is in public domain.
