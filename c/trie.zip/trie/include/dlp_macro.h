/*

*/

#pragma once

#include <linux/kernel.h>
#include <linux/module.h>



// #ifndef NO_MODULE
// #include <linux/kernel.h>
// //#include <linux/slab.h>
// #define DLP_PRINT pr_info
// #define DLP_MALLOC(size) kmalloc((size), GFP_KERNEL)
// #define DLP_FREE kfree
// #else
// #include <stdio.h>
// #include <string.h>
// #include <stdlib.h>
// #define DLP_PRINT printf
// #define DLP_MALLOC(size) malloc((size))
// #define DLP_FREE free
// #endif
