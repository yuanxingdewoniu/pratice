/*
 * Copyright (C) 2020 ~ 2021 统信软件技术有限公司
 *
 * Author:  Aaron <zhangya@uniontech.com>
 *
 * Maintainer: Aaron <zhangya@uniontech.com>
 *
 */

#pragma once

#include <linux/limits.h>

// 序列化所需的最大内存空间
#define MAX_APP_RULE_SIZE   (PATH_MAX + sizeof(unsigned int))
#define MAX_RULE_SIZE       (MAX_APP_RULE_SIZE + sizeof(int)*2)
#define MAX_FILE_RULE_SIZE  (PATH_MAX + MAX_RULE_SIZE)


#define MODULE_NAME "uos_dlp"

/* 描述
uid:        拥有权限的用户id
app_path：  存储应用程序的路径
acl：       应用程序对应的权限
*/
typedef struct __app_rule__ {
        unsigned int uid;
        char* app_path;
        unsigned int acl;
} app_rule;

/*
描述 
app_rules:　规则列表
rule_size:　规则列表数量
*/
typedef struct __rule__ {
        app_rule* app_rules;
        int rule_size;
} rule;

/*
描述 
dlp_path: 保护路径
*/
typedef struct _dlp_rule_ {
        char* dlp_path;
        rule rule;
} dlp_rule;

// 释放dlp rule
void free_dlp_rule(dlp_rule* fr);

// 释放rule
void free_rule(rule* r);

// 释放app rule
void free_app_rule(app_rule* ar);

