#!/bin/bash
gcc -fPIC -g trietree.c -I /usr/src  -o trie
