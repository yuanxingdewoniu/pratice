#!/bin/bash
gcc -fPIC -g trietree.c   -o trie
