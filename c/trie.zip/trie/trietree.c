
/*
 * Copyright (C) 2020 ~ 2021 统信软件技术有限公司
 *
 * Author:  Aaron <zhangya@uniontech.com>
 *
 * Maintainer: Aaron <zhangya@uniontech.com>
 *
 */
#include <stddef.h>
#include "include/trie_tree.h"
#include <linux/limits.h>
#include "include/dlp_macro.h"

#include <linux/module.h>

#define PATH_MAX        4096
#define FOLDER_PATH "/etc/filearmor.d/folder.config"


#define NO_MODULE

#ifndef NO_MODULE
#include <linux/kernel.h>
#include <linux/slab.h>
#define DLP_PRINT printk
#define DLP_MALLOC(size) kmalloc((size), GFP_KERNEL)
#define DLP_FREE kfree
#else
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
  
#define DLP_PRINT(format, ...) \
            printf("[%s:%d->%s] "format, __FILE__, __LINE__, __func__, ##__VA_ARGS__)
//#define DLP_PRINT printf
#define DLP_MALLOC(size) malloc((size))
#define DLP_FREE free
#endif

#ifndef max
#define max(a,b) (((a) > (b)) ? (a) : (b))
#define min(a,b) (((a) < (b)) ? (a) : (b))
#endif

static void (*trie_free_func)(void* ) = NULL;
/*
void trie_print(const dlp_rule* dr)
{
        if (NULL == dr) {
                return;
        }

        DLP_PRINT("dlp_path=%s, path_acl_size = %u", dr->dlp_path,
                  dr->rule.rule_size);

        for (int i = 0; i < dr->rule.rule_size; ++i) {
                DLP_PRINT("    app_rules %d: app_path = %s, uid = %u, acl = %u", i,
                          (dr->rule.app_rules + i)->app_path,
                          (dr->rule.app_rules + i)->uid,
                          (dr->rule.app_rules + i)->acl);
        }
}
*/
void free_data_func(void * data)
{
 printf("free data %p \n",data);
}


void node_print(TireNode* tree, int nest)
{
        if (tree) {
                for (int i = 0; i < nest; ++i) {
                        DLP_PRINT("--");
                }
                DLP_PRINT("|%s\n", tree->node_name);
                if (tree->data) {
                        for (int i = 0; i < nest; ++i) {
                                DLP_PRINT("  ");
                        }
                }
                //trie_print(tree->data);
        }

        ++nest;

        DLP_PRINT("tree->childs = %p child_count = %d, child_capacity = %d\n",
                  tree->childs, tree->child_count, tree->child_capacity);
        if (tree->childs) {
                for (unsigned int i = 0; i < tree->child_count; ++i) {
                        node_print(*(tree->childs + i), nest);
                }
        }
}

TireNode* trie_create(void)
{
        TireNode* node = (TireNode* ) DLP_MALLOC(sizeof(TireNode));

        memset(node, 0, sizeof(TireNode));

        return node;
}

int trie_free(TireNode* tree)
{
        int i = 0 ;
        if (tree == NULL) {
                return -1;
        }

        if (tree->childs && tree->child_count > 0) {
                for (int i = 0; i < tree->child_count; ++i) {
                        trie_free(*(tree->childs + i));
                        DLP_FREE(*(tree->childs + i));
                }
    
                DLP_FREE(tree->childs);
                tree->childs = NULL;
                i++;

		}

        if (tree->data) {
               trie_free_func(tree->data);
                DLP_FREE(tree->data);
                tree->data = NULL;
        }

		
		return 0 ;
}

TireNode* tire_node_create(const char* node_name, unsigned short node_len,
                           void* data)
{
        TireNode* node = (TireNode* ) DLP_MALLOC(sizeof(TireNode));

        node->node_name = (char* ) DLP_MALLOC(node_len + 1);

        memcpy(node->node_name, node_name, node_len);
        node->node_name[node_len] = '\0';

        node->node_len = node_len;

        node->data = data;
        node->childs = NULL;
        node->child_count = 0;
        node->child_capacity = 0;

        return node;
}

static int tire_compare(const char* path, unsigned short path_len,
                        const TireNode* node)
{
        if (NULL == path) {
                return -1;
        }

        if (NULL == node) {
                return 1;
        }

        if (NULL == node->node_name) {
                return 1;
        }

        return strncmp(path, node->node_name, path_len);
}

size_t tire_recommend(size_t __new_size, size_t cap)
{
        size_t two_cap = 2 * cap;

        return max(two_cap, __new_size);
}

int trie_delete_child(TireNode* tree, const char* path,
                           unsigned short path_len)
{
        int position;
        int res = trie_search(tree, path, path_len, &position);
        if (0 != res) {
                return -1;
        }

        TireNode* child = *(tree->childs + position);
        trie_free(child);

        if (position + 1 == tree->child_count) {
                *(tree->childs + position) = NULL;
                --tree->child_count;
                return 0;
        }

        memmove(tree->childs + position, tree->childs + position + 1,
                (tree->child_count - position) * sizeof(TireNode* ));
        --tree->child_count;
        *(tree->childs + tree->child_count) = NULL;
        return 0;
}
static int trie_bsearch(const char* path, unsigned short path_len,
                                 TireNode** childs, int child_count, int* position)
{
        int __l, __u;
        int __idx = 0;
        const TireNode* __p;
        int __comparison = 0;

        __l = 0;
        __u = child_count;
        while (__l < __u) {
                __idx = (__l + __u) / 2;
                __p = *(childs + __idx);
                __comparison = tire_compare(path, path_len, __p);
                if (__comparison < 0)
                        __u = __idx;
                else if (__comparison > 0)
                        __l = __idx + 1;
                else {
                        DLP_PRINT("-----1------trie_bsearch child_count = %d path = %s ,path_len = %d position = %d \n",
                                 child_count, path, path_len, *position);
                        *position = __idx;
                        return 0;
                }
        }
        if (__comparison > 0) {
                *position = __idx + 1;
                 DLP_PRINT ("------2-------trie_bsearch child_count = %d path = %s ,path_len = %d position = %d \n",
                         child_count, path, path_len, *position);
        } else {
                *position = __idx;
                 DLP_PRINT("--------3------trie_bsearch child_count = %d path = %s ,path_len = %d position = %d \n",
                          child_count, path, path_len, *position);
        }

        return -1;
}

int trie_search(TireNode* tree, const char* path, unsigned short path_len, int* position)
{
        if (NULL == tree || NULL == path) {
                *position = 0;
                return -1;
        }

        if (NULL == tree->childs) {
                *position = 0;
                return -1;
        }

        return trie_bsearch(path, path_len, tree->childs,
                                 tree->child_count, position);
}


void* trie_get_child(TireNode* tree, const char* path,
                          unsigned short path_len)
{
        //DLP_PRINT("trie_get_child path = %s tree = %p", path, tree);
        if (0 == strncmp(tree->node_name, path, PATH_MAX)) {
                return tree->data;
        }

        int position;
        int res = trie_search(tree, path, path_len, &position);
        if (0 != res) {
                DLP_PRINT("trie_get_child res != 0");
                return NULL;
        }

        TireNode* child = *(tree->childs + position);
        return child->data;
}

TireNode* trie_insert_child(TireNode* tree, const char* path,
                                 unsigned short path_len, void* data)
{
        TireNode* child = NULL;
        int position;
        TireNode** temp;

        int res = trie_search(tree, path, path_len, &position);

        //已经存在的数据直接替换
        if(res == 0) {
                child = *(tree->childs + position);
                if (data) {
                        trie_free_func(child->data);
                        child->data = data;
                }

                return child;
        }

        child = tire_node_create(path, path_len, data);

        if (tree->childs == NULL) {
                tree->childs = DLP_MALLOC(sizeof(TireNode* ));
                *(tree->childs) = child;
                tree->child_count = 1;
                tree->child_capacity = 1;
        } else {
                if (position == tree->child_count) {
                        if (tree->child_capacity < tree->child_count + 1) {
                                tree->child_capacity =
                                        tire_recommend(tree->child_count,
                                                        tree->child_capacity);
                                temp = tree->childs;
                                tree->childs = DLP_MALLOC(tree->child_capacity *
                                                        sizeof(TireNode* ));
                                memcpy(tree->childs, temp, (tree->child_count) *
                                                sizeof(TireNode* ));
                                DLP_FREE(temp);
                        }

                        *(tree->childs + tree->child_count) = child;
                        ++tree->child_count;
                } else {
                        if (tree->child_capacity < tree->child_count + 1) {
                                tree->child_capacity = tire_recommend(tree->child_count,
                                                        tree->child_capacity);
                                temp = tree->childs;
                                tree->childs = DLP_MALLOC(tree->child_capacity *
                                                        sizeof(TireNode* ));
                                if (position > 0) {
                                        memcpy(tree->childs, temp,
                                                position * sizeof(TireNode* ));
                                }
                                *(tree->childs + position) = child;
                                memcpy(tree->childs + position + 1,
                                        temp + position,
                                        (tree->child_count -position) * sizeof(TireNode* ));
                                DLP_FREE(temp);
                        } else {
                                memmove(tree->childs + (position + 1),
                                        tree->childs + (position),
                                        (tree->child_count - position) *
                                        sizeof(TireNode* ));
                                *(tree->childs + position) = child;
                        }

                        ++tree->child_count;
                }
        }

        return child;
}

int trie_insert(TireNode* tree, const char* path, unsigned short path_len,
                         void* data)
{
        int get_node_name = 0;
        unsigned short word_size = 0;
        const char* node_start = 0;
        unsigned short i = 0;
        TireNode* node;

         DLP_PRINT("trie_insert path = %s data = %p\n path_len = %d \n", path, data, path_len);

        if (tree == NULL) {
                return -1;
        }

        if (path == NULL) {
                return -1;
        }

        for (i = 0; i < path_len; ++i) {
                if (path[i] == '\\' || path[i] == '/') {
                        if (word_size > 0) {
                                get_node_name = 1; //
                        }

                        continue;
                }

                if (word_size == 0) {
                        node_start = &path[i];
                        DLP_PRINT("&path[i] = %s \n", &path[i]);
                }

                if (get_node_name) {
                        // node = trie_insert_child(tree, node_start, word_size,
                        //                            NULL);
                        node = trie_insert_child(tree, node_start, word_size,
                                                NULL);

                        return trie_insert(node, path + i, path_len - i,
                                                data);
                }
               
                word_size++;
                DLP_PRINT("word_size= %d \n", word_size);
        }

        if (i == path_len) {
                trie_insert_child(tree, node_start, word_size, data);
                return 0;
        }

        return -1;
}

//static



int trie_delete(TireNode* tree, const char* path, unsigned short path_len)
{
        TireNode* child;
        int get_node_name = 0;
        unsigned short word_size = 0;
        const char* node_start = 0;
        unsigned short i = 0;
        int position;
        int res;

        if (tree == NULL || path == NULL) {
                return -1;
        }

        for (i = 0; i < path_len; ++i) {
                if (path[i] == '\\' || path[i] == '/') {
                        if (word_size > 0) {
                                get_node_name = 1;
                        }

                        continue;
                }

                if (word_size == 0) {
                        node_start = &path[i];
                }

                if (get_node_name) {
                        res = trie_search(tree, node_start, word_size,
                                                 &position);
                        if (res != 0) {
                                return -1;
                        }

                        child = *(tree->childs + position);
                        return trie_delete(child, path + i, path_len - i);
                }

                word_size++;
        }

        if (i == path_len) {
                if (0 != trie_delete_child(tree, node_start, word_size)) {
                        return -1;
                }
        }

        return 0;
}

void* trie_get(TireNode* tree, const char* path,
                         unsigned short path_len)
{
        int get_node_name = 0;
        unsigned short word_size = 0;
        const char* node_start = 0;
        unsigned short i = 0;
        int position;
        void* result = tree->data;
        TireNode* child;
        void* pd;
        int res;

        DLP_PRINT("^^^^^^^111^^^^^^trie_get path = %s, path_len = %d tree = %p \n", path, path_len, tree);

        if (tree == NULL) {
                return NULL;
        }

        if (path == NULL) {
                return NULL;
        }

        for (i = 0; i < path_len; ++i) {
                if (path[i] == '\\' || path[i] == '/') {
                        if (word_size > 0) {
                                get_node_name = 1;
                        }

                        continue;
                }

                if (word_size == 0) {
                        node_start = path + i;
                }

                if (get_node_name) {
                        res = trie_search(tree, node_start, word_size,
                                                 &position);
                        if (res != 0) {
                                return result;
                        }


                       DLP_PRINT("node_start =  %s\n", node_start);
                        child = *(tree->childs + position);
                        pd = trie_get(child, path + i, path_len - i);
                        if (pd) {
                                return pd;
                        }

                        return result;
                }

                word_size++;
        }

        if (i == path_len) {
                pd = trie_get_child(tree, node_start, word_size);
                if (pd) {
                        result = pd;
                }
        }

        return result;
}

void trie_set_free_func(void (*free_func)(void* ))
{
        trie_free_func = free_func;
}


char* check_folder_rules(const char *name,char* return_path)
{

        FILE *profile_file = NULL;
		char StrLine[256] = {0};
        profile_file  =  fopen(FOLDER_PATH, "r");

        if ( profile_file   == NULL)
        {
            DLP_PRINT("open file failed \n");

        }


        while (!feof(profile_file)) {
        fgets(StrLine, 255, profile_file);  //读取一行

	   printf("get path strlen(StrLine)= %d, name = %s \n StrLine = %s\n return_path = %s \n strstr(name, Strline) =%s \n ", 
		strlen(StrLine),	   name, StrLine, return_path, 	strstr(name,StrLine));


	   if (strstr(name, StrLine) != NULL)
	    {
	        return_path = StrLine;

		}
       }
      return return_path;
}


int serialize_path(const char* path, void* data)
{
        int path_len;

        if (path == NULL) {
                return -1;
        }

        path_len = strlen(path);
        if (path_len >= PATH_MAX) {
                return -1;
        }

        *((int*) data) = path_len + 1;
        memcpy((char* ) data + sizeof(int), path, path_len + 1);

        return sizeof(int) + path_len + 1;
}

int unserialize_path(const void* data, char** path)
{
        int len = 0;

//    *path = NULL;
        if (data == NULL) {
                return -1;
        }

        len = *((int*) data);

        if (len > PATH_MAX || len < 0) {
                return -1;
        }
		
		*path =(void *)  DLP_MALLOC(len);
         memcpy(*path, data + sizeof(int), len);
        return len + sizeof(int);
}


void test_serialize_path(char* path)
{
        void* data = DLP_MALLOC(PATH_MAX);

        int size = serialize_path(path, data);
        DLP_PRINT("serialize_path size = %d\n", size);

       char* path_out1 = NULL ;

      size = unserialize_path(data, &path_out1);
      DLP_PRINT("unserialize_path size = %d, out = %s\n", size, path_out1);
     
	  DLP_FREE(data);
}


int main()
{

        TireNode* tree = trie_create();


		trie_set_free_func(free_data_func);


 /*     char *name = "/home/wxl/test/1/1/1/1";
       char *return_path = NULL;

        test_serialize_path("/home/opt/aaaa/bbb/eee.exe");
        test_serialize_path("NULL");
        test_serialize_path("");
        test_serialize_path("321312431423421/143213//1231/1233121////23131232");
        test_serialize_path(" ");
*/
		


		// void *test1 = malloc(1);
		// trie_insert(tree, 
		// 		"/home/wxl/test/3/a36ac5a4cc410d63222",
		// 		strlen("/home/wxl/test/10010/a36ac5a4cc410d63222"),
  //               test1);


  //      void *test2 = malloc(1);
  //       trie_insert(tree, 
  //               "/home/wxl/22/4/",
  //               strlen("/home/wxl/22/4/"),
  //               test2);

  //       void *test3 = malloc(1);
  //       trie_insert(tree, 
  //               "/home/wxl/test/3a36ac5a4cc410d63222",
  //               strlen("/home/wxl/test/3a36ac5a4cc410d63222"),
  //               test3);


  //   void *test4= malloc(1);
  //       trie_insert(tree, 
  //               "/home/wxl3222/",
  //               strlen("/home/wxl3222/"),
  //               test4);

  //   void *test5= malloc(1);
  //       trie_insert(tree, 
  //               "/home/wxl/test/3/52",
  //               strlen("/home/wxl/test/3/52"),
  //               test5);

  //   void *test6= malloc(1);
  //       trie_insert(tree, 
  //               "/home/1wxl/test/3/52",
  //               strlen("/home/1wxl/test/3/52"),
  //               test6);

		//  trie_insert(tree, StrLine, strlen(StrLine), test);

/***插入的位置可以发现，那么就在目录中****/



            void *test7= malloc(1);
            trie_insert(tree, 
            "/home/1wxl/test/3/5/",
            strlen("/home/1wxl/test/3/5"),
            test7);


           
            char *res = trie_get(tree, "/home/1wxl/test/3/5/2111111111111111",
            strlen("/home/1wxl/test/3/5/211111111111"));
            printf(" $$$$$$$$$$3$$$$$$$$$$$$ res = %s \n", res);


            void *test8 = malloc(1);
            trie_insert(tree, 
            "/home/wxl3/222/",
            strlen("/home/wxl3/222/"),
            test8);

            void *test9= malloc(1);
            trie_insert(tree, 
            "/home/wxl3/22233/",
            strlen("/home/wxl3/22233/"),
            test9);

// 获取数据 路径的数据不存在 若dlp data为NULL，使用父路径的dlp数据
//void* trie_get(TireNode* tree, const char* path, unsigned short path_len);
// 直接比对文本的信息， 返回路径信息，用新的路径进行匹配。


            // res = trie_get(tree,"/home/wxl3/222/11",
            // strlen("/home/wxl3/222/11"));
            // printf("$$$$$$4$$$$ res = %s \n", res);

            trie_free(tree);

//         
//         if(test  != NULL )
  //       free(test);
    //char *result  = check_folder_rules(name, return_path);
    // printf("-----------check folder_rules return_path= %s -------------- \n", return_path);
   
   return 0;
}
